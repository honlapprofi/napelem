<?php
function LanguageSwitcher() {
    $translation = get_post_meta( get_the_ID(), 'translation', true);
 
	if( ! empty( $translation ) ) {
		$pos = strpos($translation, '/en/');
		if ($pos !== false) {
			echo '<a href=',$translation,'><img src="https://bandart.eu/en.png"/> ENGLISH</a>';
		} else {
			echo '<a href=',$translation,'><img src="https://bandart.eu/hu.png"/> MAGYAR</a>';
		}
	}
}
add_shortcode('translate', 'LanguageSwitcher');

function LSwitcher() {
    $translation = get_post_meta( get_the_ID(), 'translation', true);
 
	if( ! empty( $translation ) ) {
		echo $translation;
	}
}
add_shortcode('switch', 'LSwitcher');

function fav() { 
	{ ?><link rel="shortcut icon" href="/S_favicon.png" ><?php }
}
add_action('wp_head', 'fav');

?>